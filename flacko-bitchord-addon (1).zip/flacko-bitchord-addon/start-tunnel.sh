#!/bin/bash
# FLACKO — link publik sementara (gratis, 60 menit, URL berubah tiap jalan)
# Syarat: server FLACKO sudah jalan (node server.js), dan ssh terinstall.
# Jalankan script ini, copy URL https://.... yang muncul, tempel
# URL itu + /manifest.json di BitChord -> Settings -> Sources -> Add an addon.
# Contoh: https://xxxx.run.pinggy-free.link/manifest.json
# Untuk link permanen, deploy ke Render (lihat README, Opsi A).
ssh -p 443 -o StrictHostKeyChecking=no -R0:localhost:3000 free.pinggy.io -T
